package com.cts.management.service;


import com.cts.management.DTO.CompanyRequest;
import com.cts.management.DTO.StockPriceRequest;
import com.cts.management.entity.Company;
import com.cts.management.entity.StockPrice;
import com.cts.management.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CompanyService {

    @Autowired
    private CompanyRepository companyRepository;

    public void registerCompany(CompanyRequest companyRequest) {
        Company company = new Company();
        company.setCompanyCode(companyRequest.getCompanyCode());
        company.setName(companyRequest.getName());
        company.setCEO(companyRequest.getCEO());
        company.setTurnover(companyRequest.getTurnover());
        company.setWebsite(companyRequest.getWebsite());
        company.setStockExchange(companyRequest.getStockExchange());

        companyRepository.save(company);
    }

    public Company getCompanyDetails(String companycode) {
        return companyRepository.findByCompanyCode(companycode).orElse(null);
    }

    public List<Company> getAllCompaniesWithLatestStockPrice() {
        return companyRepository.findAll();
    }

    public void deleteCompany(String companycode) {
        companyRepository.findByCompanyCode(companycode).ifPresent(companyRepository::delete);
    }

    public void addOrUpdateStockPrice(String companycode, StockPriceRequest stockPriceRequest) {
        Company company = companyRepository.findByCompanyCode(companycode)
                .orElseThrow(() -> new RuntimeException("Company not found"));

        StockPrice newStockPrice = new StockPrice();
        newStockPrice.setStockPrice(stockPriceRequest.getStockPrice());
        newStockPrice.setDateTime(LocalDateTime.now());

        company.getStockPrices().add(newStockPrice);
        newStockPrice.setCompany(company);

        companyRepository.save(company);
    }

    public void updateCompanyDetails(String companycode, CompanyRequest updatedCompanyRequest) {
        Company company = companyRepository.findByCompanyCode(companycode)
                .orElseThrow(() -> new RuntimeException("Company not found"));

        company.setName(updatedCompanyRequest.getName());
        company.setCEO(updatedCompanyRequest.getCEO());
        company.setTurnover(updatedCompanyRequest.getTurnover());
        company.setWebsite(updatedCompanyRequest.getWebsite());
        company.setStockExchange(updatedCompanyRequest.getStockExchange());

        companyRepository.save(company);
    }
}
