package com.cts.management.controller;

import com.cts.management.DTO.CompanyRequest;
import com.cts.management.DTO.StockPriceRequest;
import com.cts.management.entity.Company;
import com.cts.management.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1.0/market/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @PostMapping("/register")
    public ResponseEntity<String> registerCompany(@RequestBody CompanyRequest companyRequest) {
        companyService.registerCompany(companyRequest);
        return ResponseEntity.ok("Company registered successfully");
    }

    @GetMapping("/info/{companycode}")
    public ResponseEntity<CompanyRequest> getCompanyDetails(@PathVariable String companycode) {
        Company company = companyService.getCompanyDetails(companycode);
        if (company != null) {
            CompanyRequest response = new CompanyRequest();
            response.setCompanyCode(company.getCompanyCode());
            response.setName(company.getName());
            response.setCEO(company.getCEO());
            response.setTurnover(company.getTurnover());
            response.setWebsite(company.getWebsite());
            response.setStockExchange(company.getStockExchange());
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/getall")
    public ResponseEntity<List<CompanyRequest>> getAllCompaniesWithLatestStockPrice() {
        List<Company> companies = companyService.getAllCompaniesWithLatestStockPrice();
        List<CompanyRequest> responses = companies.stream()
                .map(company -> {
                    CompanyRequest response = new CompanyRequest();
                    response.setCompanyCode(company.getCompanyCode());
                    response.setName(company.getName());
                    response.setCEO(company.getCEO());
                    response.setTurnover(company.getTurnover());
                    response.setWebsite(company.getWebsite());
                    response.setStockExchange(company.getStockExchange());
                    return response;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }

    @DeleteMapping("/delete/{companycode}")
    public ResponseEntity<String> deleteCompany(@PathVariable String companycode) {
        companyService.deleteCompany(companycode);
        return ResponseEntity.ok("Company deleted successfully");
    }

    @PostMapping("/stock/add/{companycode}")
    public ResponseEntity<String> addOrUpdateStockPrice(
            @PathVariable String companycode,
            @RequestBody StockPriceRequest stockPriceRequest) {
        companyService.addOrUpdateStockPrice(companycode, stockPriceRequest);
        return ResponseEntity.ok("Stock price added/updated successfully");
    }

    @PutMapping("/put/{companycode}")
    public ResponseEntity<String> updateCompanyDetails(
            @PathVariable String companycode,
            @RequestBody CompanyRequest updatedCompanyRequest) {
        companyService.updateCompanyDetails(companycode, updatedCompanyRequest);
        return ResponseEntity.ok("Company details updated successfully");
    }
}
