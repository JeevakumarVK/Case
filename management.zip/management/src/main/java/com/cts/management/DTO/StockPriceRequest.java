package com.cts.management.DTO;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockPriceRequest {

    private Double stockPrice;
}
