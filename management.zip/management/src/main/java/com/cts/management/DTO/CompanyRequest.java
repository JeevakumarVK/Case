package com.cts.management.DTO;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyRequest {

    private String companyCode;
    private String name;
    private String CEO;
    private Double turnover;
    private String website;
    private String stockExchange;
}
